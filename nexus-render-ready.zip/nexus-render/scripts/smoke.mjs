process.env.NODE_ENV = "test";
process.env.JWT_SECRET = "test-secret-that-is-long-enough-for-local-smoke";
process.env.PORT = "3199";
const { server } = await import("../server.mjs");

const base = "http://127.0.0.1:3199";
const email = `smoke-${Date.now()}@example.com`;
try {
  const health = await fetch(`${base}/api/health`).then((r) => r.json());
  if (!health.ok) throw new Error("Health check failed");
  const registerResponse = await fetch(`${base}/api/auth/register`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ name: "Smoke User", email, password: "smoke-password" }) });
  const cookie = registerResponse.headers.get("set-cookie");
  if (!registerResponse.ok || !cookie) throw new Error(`Register failed: ${await registerResponse.text()}`);
  const diagnosticResponse = await fetch(`${base}/api/diagnostics`, { method: "POST", headers: { "content-type": "application/json", cookie }, body: JSON.stringify({ cpu: "Ryzen 5 5600", gpu: "RTX 3060", ram: 16, storage: "nvme", cooling: "normal", resolution: "1080p", refreshRate: 144, game: "Counter-Strike 2", currentFps: 120, ping: 31 }) });
  const diagnostic = await diagnosticResponse.json();
  if (!diagnosticResponse.ok || !diagnostic.result?.score) throw new Error(`Diagnostic failed: ${JSON.stringify(diagnostic)}`);
  const subscriptionResponse = await fetch(`${base}/api/subscriptions`, { method: "POST", headers: { "content-type": "application/json", cookie }, body: JSON.stringify({ plan: "pro" }) });
  if (!subscriptionResponse.ok) throw new Error(`Subscription failed: ${await subscriptionResponse.text()}`);
  const recovery = await fetch(`${base}/api/auth/recover`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ email }) }).then((r) => r.json());
  if (!recovery.previewToken) throw new Error("Recovery token was not created in test mode");
  const resetResponse = await fetch(`${base}/api/auth/reset`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ token: recovery.previewToken, password: "new-smoke-password" }) });
  if (!resetResponse.ok) throw new Error(`Reset failed: ${await resetResponse.text()}`);
  const config = await fetch(`${base}/api/public-config`).then((r) => r.json());
  if (config.settings.discount_percent !== 70 || config.games.length !== 20) throw new Error("Public config seed failed");
  console.log(JSON.stringify({ ok: true, score: diagnostic.result.score, games: config.games.length, discount: config.settings.discount_percent }));
} finally {
  await new Promise((resolve) => server.close(resolve));
}

import "dotenv/config";
import bcrypt from "bcryptjs";
import { initDb, query, closeDb } from "../db.mjs";

const [command, action, ...args] = process.argv.slice(2);
const flags = Object.fromEntries(args.filter((x) => x.startsWith("--")).map((x) => { const [key, ...value] = x.slice(2).split("="); return [key, value.join("=") || true]; }));

function help() {
  console.log(`
Nexus Admin CLI

  npm run admin -- stats
  npm run admin -- settings list
  npm run admin -- settings set --key=discount_percent --value=70
  npm run admin -- discount set --percent=70
  npm run admin -- plan set --slug=pro --regular=11.99 --first=3.60
  npm run admin -- game add --name="Game" --genre=FPS --steam=730
  npm run admin -- game disable --name="Game"
  npm run admin -- user create-admin --name="Owner" --email=you@example.com --password="strong-password"
  npm run admin -- user promote --email=you@example.com
  npm run admin -- diagnostics list --limit=20
`);
}

await initDb();
try {
  if (!command || command === "help") help();
  else if (command === "stats") {
    const data = await query("SELECT (SELECT COUNT(*) FROM users)::int users,(SELECT COUNT(*) FROM diagnostics)::int diagnostics,(SELECT COUNT(*) FROM subscriptions)::int subscriptions");
    console.table(data.rows);
  } else if (command === "settings" && action === "list") {
    console.table((await query("SELECT key,value,updated_at FROM settings ORDER BY key")).rows);
  } else if (command === "settings" && action === "set" && flags.key) {
    let value;
    try { value = JSON.parse(String(flags.value)); } catch { value = String(flags.value); }
    await query("INSERT INTO settings(key,value) VALUES($1,$2::jsonb) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_at=NOW()", [flags.key, JSON.stringify(value)]);
    console.log(`Updated ${flags.key}`);
  } else if (command === "discount" && action === "set" && flags.percent) {
    const percent = Math.max(0, Math.min(95, Number(flags.percent)));
    await query("INSERT INTO settings(key,value) VALUES('discount_percent',$1::jsonb) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_at=NOW()", [JSON.stringify(percent)]);
    await query("UPDATE plans SET first_month_price=ROUND(regular_price*(100-$1)/100,2),updated_at=NOW()", [percent]);
    console.log(`First-month discount updated to ${percent}%`);
  } else if (command === "plan" && action === "set" && flags.slug) {
    await query("UPDATE plans SET regular_price=COALESCE($2,regular_price),first_month_price=COALESCE($3,first_month_price),updated_at=NOW() WHERE slug=$1", [flags.slug, flags.regular || null, flags.first || null]);
    console.log(`Updated plan ${flags.slug}`);
  } else if (command === "game" && action === "add" && flags.name && flags.genre) {
    await query("INSERT INTO games(name,genre,steam_app_id,sort_order) VALUES($1,$2,$3,COALESCE((SELECT MAX(sort_order)+1 FROM games),0)) ON CONFLICT(name) DO UPDATE SET genre=EXCLUDED.genre,steam_app_id=EXCLUDED.steam_app_id,active=TRUE", [flags.name, flags.genre, flags.steam || null]);
    console.log(`Saved game ${flags.name}`);
  } else if (command === "game" && action === "disable" && flags.name) {
    await query("UPDATE games SET active=FALSE WHERE name=$1", [flags.name]);
    console.log(`Disabled game ${flags.name}`);
  } else if (command === "user" && action === "create-admin" && flags.name && flags.email && flags.password) {
    const hash = await bcrypt.hash(String(flags.password), 12);
    await query("INSERT INTO users(name,email,password_hash,role) VALUES($1,LOWER($2),$3,'admin') ON CONFLICT(email) DO UPDATE SET name=EXCLUDED.name,password_hash=EXCLUDED.password_hash,role='admin'", [flags.name, flags.email, hash]);
    console.log(`Admin ready: ${flags.email}`);
  } else if (command === "user" && action === "promote" && flags.email) {
    await query("UPDATE users SET role='admin' WHERE email=LOWER($1)", [flags.email]);
    console.log(`Promoted: ${flags.email}`);
  } else if (command === "diagnostics" && action === "list") {
    const limit = Math.max(1, Math.min(100, Number(flags.limit || 20)));
    const rows = await query("SELECT d.id,u.email,d.output->>'score' score,d.output->>'bottleneck' bottleneck,d.created_at FROM diagnostics d JOIN users u ON u.id=d.user_id ORDER BY d.created_at DESC LIMIT $1", [limit]);
    console.table(rows.rows);
  } else {
    help();
    process.exitCode = 1;
  }
} finally {
  await closeDb();
}

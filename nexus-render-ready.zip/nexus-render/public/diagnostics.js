const $ = (selector, root = document) => root.querySelector(selector);
const form = $("#diagnostic-form");
let step = 1;

async function api(url, options = {}) {
  const response = await fetch(url, { credentials: "same-origin", headers: { "content-type": "application/json" }, ...options });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || "Не удалось выполнить запрос");
  return body;
}

function showStep(next) {
  step = Math.max(1, Math.min(3, next));
  document.querySelectorAll(".form-step").forEach((node) => node.classList.toggle("active", Number(node.dataset.step) === step));
  $("#form-step").textContent = step;
  $("#step-title").textContent = ["", "Комплектующие", "Игровой сценарий", "Подтверждение"][step];
  $("#form-progress").style.width = `${step / 3 * 100}%`;
  $("#step-back").hidden = step === 1;
  $("#step-next").hidden = step === 3;
  $("#diagnostic-submit").hidden = step !== 3;
}

function validateCurrentStep() {
  const current = $(`.form-step[data-step="${step}"]`);
  const invalid = [...current.querySelectorAll("input[required],select[required]")].find((input) => !input.reportValidity());
  return !invalid;
}

function renderResult(payload) {
  const result = payload.result || payload.output;
  const input = payload.input;
  $("#result-score").textContent = result.score;
  $("#result-profile").textContent = result.profile;
  $("#result-bottleneck").textContent = result.bottleneck;
  $("#result-current").textContent = `${input.currentFps} FPS`;
  $("#result-fps").textContent = `${result.expectedFps.from}–${result.expectedFps.to} FPS`;
  $("#result-gain").textContent = `+${result.gain.from}–${result.gain.to}%`;
  $("#result-latency").textContent = result.latency;
  $("#result-disclaimer").textContent = result.disclaimer;
  $("#result-recommendations").innerHTML = `<h3>Приоритетный план</h3>${result.recommendations.map((item, index) => `<article><b>${String(index + 1).padStart(2, "0")}</b><div><span>${item.impact}</span><h4>${item.title}</h4><p>${item.detail}</p></div></article>`).join("")}`;
  $("#result-content").hidden = false;
  $("#result-empty").hidden = true;
  $("#result-loading").hidden = true;
}

async function loadUser() {
  try {
    const { user } = await api("/api/auth/me");
    $("#diag-user").textContent = user.name;
    const latest = await api("/api/diagnostics/latest");
    if (latest.diagnostic) renderResult({ input: latest.diagnostic.input, output: latest.diagnostic.output });
  } catch {
    $("#diag-user").textContent = "Нужен вход";
    $("#diagnostic-message").innerHTML = 'Для сохранения результата сначала <a href="/?auth=register">создайте Nexus ID</a>.';
  }
}

$("#step-next").addEventListener("click", () => { if (validateCurrentStep()) showStep(step + 1); });
$("#step-back").addEventListener("click", () => showStep(step - 1));
form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(form));
  data.ram = Number(data.ram); data.refreshRate = Number(data.refreshRate); data.currentFps = Number(data.currentFps); data.ping = Number(data.ping);
  $("#diagnostic-message").textContent = "";
  $("#result-empty").hidden = true; $("#result-content").hidden = true; $("#result-loading").hidden = false;
  let percent = 0;
  const labels = ["Сопоставляем комплектующие…", "Проверяем игровой сценарий…", "Оцениваем узкое место…", "Формируем личный план…"];
  const timer = setInterval(() => { percent = Math.min(94, percent + Math.ceil(Math.random() * 11)); $("#scan-percent").textContent = `${percent}%`; $("#scan-label").textContent = labels[Math.min(3, Math.floor(percent / 25))]; }, 180);
  try {
    const [payload] = await Promise.all([api("/api/diagnostics", { method: "POST", body: JSON.stringify(data) }), new Promise((resolve) => setTimeout(resolve, 1500))]);
    clearInterval(timer); $("#scan-percent").textContent = "100%";
    setTimeout(() => renderResult(payload), 220);
  } catch (error) {
    clearInterval(timer); $("#result-loading").hidden = true; $("#result-empty").hidden = false; $("#diagnostic-message").textContent = error.message;
  }
});

const game = new URLSearchParams(location.search).get("game");
if (game) form.elements.game.value = game;
showStep(1); loadUser();

const state = { config: null, user: null, expanded: false, genre: "Все", query: "", authMode: "login", pendingPlan: null };
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

async function api(url, options = {}) {
  const response = await fetch(url, { credentials: "same-origin", headers: { "content-type": "application/json", ...(options.headers || {}) }, ...options });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || "Не удалось выполнить запрос");
  return body;
}

let toastTimer;
function toast(message) {
  const node = $("#toast");
  node.textContent = message;
  node.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => node.classList.remove("show"), 3200);
}

function money(value) { return Number(value).toFixed(2); }

function renderGames() {
  if (!state.config) return;
  const all = state.config.games;
  const genres = ["Все", ...new Set(all.map((game) => game.genre))];
  const filterBox = $("#game-filters");
  if (!filterBox.children.length) filterBox.innerHTML = genres.map((genre) => `<button class="${genre === state.genre ? "active" : ""}" data-genre="${genre}" type="button">${genre}</button>`).join("");
  const found = all.filter((game) => (state.genre === "Все" || game.genre === state.genre) && game.name.toLowerCase().includes(state.query));
  const limited = !state.expanded && !state.query && state.genre === "Все";
  const shown = limited ? found.slice(0, 8) : found;
  $("#game-grid").innerHTML = shown.length ? shown.map((game) => `
    <article class="game-card">
      <div class="game-image"><img loading="lazy" src="https://shared.cloudflare.steamstatic.com/store_item_assets/steam/apps/${game.steam_app_id}/header.jpg" alt="Обложка ${game.name}"></div>
      <div class="game-copy"><span>${game.genre}</span><h3>${game.name}</h3><p>Персональный профиль после диагностики</p><a href="/diagnostics.html?game=${encodeURIComponent(game.name)}">Проверить мой ПК <i>↗</i></a></div>
    </article>`).join("") : '<p class="empty-games">По этому запросу игр не найдено.</p>';
  $("#game-count").textContent = `${shown.length} из ${found.length}`;
  const toggle = $("#catalog-toggle");
  toggle.hidden = Boolean(state.query) || state.genre !== "Все";
  toggle.setAttribute("aria-expanded", String(state.expanded));
  toggle.firstChild.textContent = state.expanded ? "Свернуть каталог " : `Показать все ${all.length} игр `;
}

function renderPlans() {
  const featured = "pro";
  $("#plan-grid").innerHTML = state.config.plans.map((plan) => `
    <article class="panel plan ${plan.slug === featured ? "featured" : ""}">
      <div class="sale">−${state.config.settings.discount_percent}% · ПЕРВЫЙ МЕСЯЦ</div>
      <span class="plan-name">${plan.name}${plan.slug === featured ? " · ВЫБОР ИГРОКОВ" : ""}</span>
      <div class="price-row"><div class="first-price"><small>СЕЙЧАС</small><strong>€${money(plan.first_month_price)}</strong></div><div class="regular-price"><small>ОБЫЧНАЯ ЦЕНА</small><s>€${money(plan.regular_price)}</s></div></div>
      <p class="renewal">Со второго месяца — <b>€${money(plan.regular_price)}/мес</b></p>
      <ul>${plan.features.map((feature) => `<li>${feature}</li>`).join("")}</ul>
      <button class="button plan-button" data-plan="${plan.slug}" type="button">Выбрать ${plan.name}</button>
    </article>`).join("");
}

const dialog = $("#auth-dialog");
function updateAuthButton() {
  $$('[data-auth-open]').forEach((button) => { button.textContent = state.user ? `${state.user.name} · Выйти` : "Войти"; });
}
function setAuthMode(mode) {
  state.authMode = mode;
  $$('[data-auth-mode]').forEach((button) => button.classList.toggle("active", button.dataset.authMode === mode));
  $("#auth-name").hidden = mode !== "register";
  $("#auth-password").hidden = mode === "recover";
  $("#auth-password input").required = mode !== "recover";
  $("#auth-forgot").hidden = mode !== "login";
  const copy = mode === "login" ? ["Войти в аккаунт", "Диагностики и тарифы сохранятся в вашем Nexus ID.", "Войти"] : mode === "register" ? ["Создать Nexus ID", "Один аккаунт для диагностики и подписки.", "Создать аккаунт"] : ["Восстановить доступ", "Отправим безопасную ссылку на ваш email.", "Отправить ссылку"];
  $("#auth-title").textContent = copy[0];
  $("#auth-subtitle").textContent = copy[1];
  $("#auth-submit").textContent = copy[2];
  $("#auth-message").textContent = "";
}
function openAuth(mode = "login") { setAuthMode(mode); dialog.showModal(); }

async function handlePlan(slug) {
  if (!state.user) { state.pendingPlan = slug; openAuth("register"); return; }
  try {
    const result = await api("/api/subscriptions", { method: "POST", body: JSON.stringify({ plan: slug }) });
    if (result.checkoutUrl) window.location.href = result.checkoutUrl;
    else toast(result.message);
  } catch (error) { toast(error.message); }
}

async function initialize() {
  const configPromise = api("/api/public-config");
  const userPromise = api("/api/auth/me").catch(() => null);
  const [config, user] = await Promise.all([configPromise, userPromise]);
  state.config = config;
  state.user = user?.user || null;
  renderGames(); renderPlans(); updateAuthButton();
  $$('[data-discount-copy]').forEach((node) => { node.textContent = `СКИДКА ${config.settings.discount_percent}% ТОЛЬКО В ПЕРВЫЙ МЕСЯЦ`; });
  if (config.settings.hero_title) $(".hero h1").innerHTML = `${config.settings.hero_title.split(". ")[0]}.<span>${config.settings.hero_title.split(". ").slice(1).join(". ")}</span>`;
  const requestedMode = new URLSearchParams(location.search).get("auth");
  if (!state.user && ["login", "register", "recover"].includes(requestedMode)) openAuth(requestedMode);
}

$("#game-search").addEventListener("input", (event) => { state.query = event.target.value.trim().toLowerCase(); renderGames(); });
$("#game-filters").addEventListener("click", (event) => { const button = event.target.closest("[data-genre]"); if (!button) return; state.genre = button.dataset.genre; $$("#game-filters button").forEach((item) => item.classList.toggle("active", item === button)); renderGames(); });
$("#catalog-toggle").addEventListener("click", () => { state.expanded = !state.expanded; renderGames(); if (!state.expanded) $("#games").scrollIntoView({ behavior: "smooth" }); });
$("#plan-grid").addEventListener("click", (event) => { const button = event.target.closest("[data-plan]"); if (button) handlePlan(button.dataset.plan); });

$$('[data-auth-open]').forEach((button) => button.addEventListener("click", async () => {
  if (state.user) { await api("/api/auth/logout", { method: "POST" }); state.user = null; updateAuthButton(); toast("Вы вышли из аккаунта"); }
  else openAuth();
}));
$('[data-auth-close]').addEventListener("click", () => dialog.close());
$(".auth-tabs").addEventListener("click", (event) => { const button = event.target.closest("[data-auth-mode]"); if (button) setAuthMode(button.dataset.authMode); });
$("#auth-forgot").addEventListener("click", () => setAuthMode("recover"));
$("#auth-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(event.currentTarget));
  const message = $("#auth-message");
  message.textContent = "Проверяем…";
  try {
    if (state.authMode === "recover") { const result = await api("/api/auth/recover", { method: "POST", body: JSON.stringify({ email: data.email }) }); message.textContent = result.message; return; }
    const result = await api(`/api/auth/${state.authMode}`, { method: "POST", body: JSON.stringify(data) });
    state.user = result.user; updateAuthButton(); dialog.close(); toast(`Добро пожаловать, ${state.user.name}`);
    if (state.pendingPlan) { const plan = state.pendingPlan; state.pendingPlan = null; await handlePlan(plan); }
  } catch (error) { message.textContent = error.message; }
});

const observer = new IntersectionObserver((entries) => entries.forEach((entry) => entry.target.classList.toggle("visible", entry.isIntersecting)), { threshold: 0.08 });
$$('.reveal').forEach((node) => observer.observe(node));
const hero = $(".hero");
hero.addEventListener("pointermove", (event) => { const bounds = hero.getBoundingClientRect(); hero.style.setProperty("--x", ((event.clientX - bounds.left) / bounds.width - 0.5).toFixed(3)); hero.style.setProperty("--y", ((event.clientY - bounds.top) / bounds.height - 0.5).toFixed(3)); });
hero.addEventListener("pointerleave", () => { hero.style.setProperty("--x", 0); hero.style.setProperty("--y", 0); });

initialize().catch((error) => { console.error(error); toast("Не удалось загрузить данные сайта"); });

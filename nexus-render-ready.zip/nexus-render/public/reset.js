const form = document.querySelector("#reset-form");
form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const output = document.querySelector("#reset-message");
  const token = new URLSearchParams(location.search).get("token") || "";
  const response = await fetch("/api/auth/reset", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ token, password: new FormData(form).get("password") }) });
  const body = await response.json();
  output.textContent = body.message || body.error;
  if (response.ok) setTimeout(() => { location.href = "/"; }, 1300);
});
